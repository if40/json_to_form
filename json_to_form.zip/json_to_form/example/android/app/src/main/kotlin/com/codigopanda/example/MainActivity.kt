package com.codigopanda.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
