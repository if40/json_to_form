package com.codigopanda.json_to_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
