import 'package:flutter_test/flutter_test.dart';

import '../lib/json_to_form.dart';

void main() {
  test('adds one to input values', () {
    final jsonToForm = new CoreForm(form: null, onChanged: null);
  });
}
