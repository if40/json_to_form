
## [0.0.4] - 02/02/2020

* Fix Initial Value in TextField

## [0.0.3] - TODO: Add release date.

* Add new field Select
* You can customize the validations
* You can customize the decoration
* More stable structure

## [0.0.2] - TODO: Add release date.

* Support for dart 2 and added dartdoc

## [0.0.1] - TODO: Add release date.

* Basic convert Json to Form
